import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:brew/core/config_builder.dart';
import 'package:brew/core/link_parser.dart';

void main() {
  test('vless reality', () {
    final p = parseLink(
      'vless://11111111-2222-3333-4444-555555555555@example.com:443?type=tcp&security=reality&sni=www.microsoft.com&pbk=PUBKEY&sid=ab12&fp=chrome&flow=xtls-rprx-vision#%F0%9F%87%B3%F0%9F%87%B1%20NL',
    )!;
    expect(p['type'], 'vless');
    expect(p['server'], 'example.com');
    expect(p['port'], 443);
    expect(p['tls'], true);
    expect(p['flow'], 'xtls-rprx-vision');
    expect(p['servername'], 'www.microsoft.com');
    expect(p['reality-opts'], {'public-key': 'PUBKEY', 'short-id': 'ab12'});
    expect(p['name'], '🇳🇱 NL');
  });

  test('vless ws', () {
    final p = parseLink(
      'vless://id@h.com:8443?type=ws&security=tls&path=%2Fws&host=cdn.h.com#WS',
    )!;
    expect(p['network'], 'ws');
    expect(p['ws-opts'], {
      'path': '/ws',
      'headers': {'Host': 'cdn.h.com'},
    });
  });

  test('vmess', () {
    final json = jsonEncode({
      'v': '2',
      'ps': 'VM',
      'add': '1.2.3.4',
      'port': '443',
      'id': 'uuid',
      'aid': '0',
      'net': 'grpc',
      'path': 'svc',
      'tls': 'tls',
      'sni': 's.com',
    });
    final p = parseLink('vmess://${base64.encode(utf8.encode(json))}')!;
    expect(p['type'], 'vmess');
    expect(p['port'], 443);
    expect(p['network'], 'grpc');
    expect(p['grpc-opts'], {'grpc-service-name': 'svc'});
    expect(p['tls'], true);
  });

  test('shadowsocks SIP002 and legacy', () {
    final a = parseLink(
      'ss://${base64.encode(utf8.encode('aes-128-gcm:pass'))}@127.0.0.1:8388#A',
    )!;
    expect(a['cipher'], 'aes-128-gcm');
    expect(a['password'], 'pass');
    expect(a['port'], 8388);
    final b = parseLink(
      'ss://${base64.encode(utf8.encode('chacha20-ietf-poly1305:p@ss@1.1.1.1:443'))}#B',
    )!;
    expect(b['password'], 'p@ss');
    expect(b['server'], '1.1.1.1');
  });

  test('hysteria2 / trojan / tuic', () {
    final h = parseLink(
      'hy2://secret@h.com:443?sni=h.com&obfs=salamander&obfs-password=x&insecure=1#H',
    )!;
    expect(h['type'], 'hysteria2');
    expect(h['obfs'], 'salamander');
    expect(h['skip-cert-verify'], true);
    final t = parseLink('trojan://pw@t.com:443?sni=t.com#T')!;
    expect(t['password'], 'pw');
    final u = parseLink('tuic://uuid:pw@u.com:443?congestion_control=bbr#U')!;
    expect(u['uuid'], 'uuid');
    expect(u['congestion-controller'], 'bbr');
  });

  test('base64 subscription with duplicates', () {
    final links =
        'trojan://a@x.com:443#Same\ntrojan://b@y.com:443#Same\ngarbage';
    final sub = parseSubscription(base64.encode(utf8.encode(links)));
    expect(sub.proxies.map((e) => e['name']), ['Same', 'Same (2)']);
    final cfg = applyCoreOptions(
      baseConfigFor(sub),
      const CoreOptions(
        mixedPort: 7890,
        apiPort: 9097,
        secret: 's',
        mode: 'rule',
        tun: false,
        allowLan: false,
      ),
    );
    expect(cfg['mixed-port'], 7890);
    expect((cfg['proxy-groups'] as List).first['name'], kMainGroup);
  });

  test('clash yaml subscription', () {
    const yaml = '''
port: 7891
proxies:
  - {name: A, type: ss, server: 1.1.1.1, port: 1, cipher: aes-128-gcm, password: x}
proxy-groups:
  - {name: G, type: select, proxies: [A]}
rules:
  - MATCH,G
''';
    final sub = parseSubscription(yaml);
    expect(sub.clashConfig, isNotNull);
    final cfg = applyCoreOptions(
      baseConfigFor(sub),
      const CoreOptions(
        mixedPort: 7890,
        apiPort: 9097,
        secret: 's',
        mode: 'rule',
        tun: true,
        allowLan: false,
      ),
    );
    expect(cfg.containsKey('port'), false);
    expect(cfg['tun']['enable'], true);
    expect(cfg['dns']['enable'], true);
  });
}
